[![Runbot Status](http://runbot.adhoc.com.ar/runbot/badge/flat/6/13.0.svg)](http://runbot.adhoc.com.ar/runbot/repo/github-com-ingadhoc-odoo-argentina-6)
[![Build Status](https://travis-ci.org/ingadhoc/odoo-argentina.svg?branch=13.0)](https://travis-ci.org/ingadhoc/odoo-argentina)
[![Coverage Status](https://coveralls.io/repos/ingadhoc/odoo-argentina/badge.png?branch=13.0)](https://coveralls.io/r/ingadhoc/odoo-argentina?branch=13.0)
[![Code Climate](https://codeclimate.com/github/ingadhoc/odoo-argentina/badges/gpa.svg)](https://codeclimate.com/github/ingadhoc/odoo-argentina)

# ADHOC odoo-argentina

ADHOC Odoo odoo-argentina Modules

[//]: # (addons)
[//]: # (end addons)

Translation Status
------------------
[![Transifex Status](https://www.transifex.com/projects/p/ingadhoc-odoo-argentina-13-0/chart/image_png)](https://www.transifex.com/projects/p/ingadhoc-odoo-argentina-13-0)

----

<img alt="ADHOC" src="http://fotos.subefotos.com/83fed853c1e15a8023b86b2b22d6145bo.png" />
**Adhoc SA** - www.adhoc.com.ar
